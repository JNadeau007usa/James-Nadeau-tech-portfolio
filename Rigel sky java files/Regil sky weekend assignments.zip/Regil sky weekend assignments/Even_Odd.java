public class numberList {

		public static void main(String[] args){
		
	int[] myList = new int[20];
	
		for(int = 0; i<myList.length; i++){
			myList[i] =i*2;
		}
		for(int i: i<myList.length; i++){
			if(i%2 ==0){
			
				System.out.println("Element at index " +i + "; " +myList[i]);
		}
				System.out.println("Even Numbers");
				for(i=0; i<myList.lenght; i++){
				
					if(i%2 !=0){
					
					System.out.println("