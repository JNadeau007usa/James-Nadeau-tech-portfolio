package largestnoinarray;

import java.util.Scanner;

public class LargestNoInArrary {



		public static void main(String[] Args) {
		
			int x=8
			int y=12
			int z=4
			
			if(x>y) {
			if(x>z){
				System.out.println("X is the greates");
				
			}
			else{
				
				System.out.println("Z is the greatest");
			}
			}
			else if (y>x) {
				
				if(y>z) {
					
					System.out.println("Y is the greatest");
				}
				else {
					
					System.out.println("Z is the greatest");
				}
			}
			