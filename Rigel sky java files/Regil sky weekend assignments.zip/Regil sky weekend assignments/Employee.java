

import java.util.Scanner;

public class Employee {

	int Id;
	String Name;
	int Age;
	long Salary;
	
	void GetData() {
	
		Scanner sc = new Scanner(system.in);
		system.out.println("\n\tEnter Employee Id:");
		Id = Integer.parseInt(sc.nextLine());
		System.out.print("\n\tEnter Employee Name:");
		Name = sc.nextLine();
		System.out.print("\n\tEnterEmployeeAge:");
		Age = Integer.parseInt(sc.nextLine());
		System.out.print("\n\tEnter Employee Salary:");
		Salary = Integer.parseInt(sc.nextLine());
	}
	
	void PutData() {
	
		public static void main(String[] args) {
		
			Employee[] Emp = newEmployee[10];
			int i;
			
			for(i=0; i<10; i++)
			Emp[i] = new Employee();
			
			for(i=0; i<10; i++) {
				System.out.println("\nEnter details of "+(i+1) +" Employee\n");
					Emp[i].GetData();
				}
				
				System.out.print("\nDetails of EMployees\n");
					for(i=0; i<10; i++)
						Emp[i].PutData();
						
					}
				}
				
				